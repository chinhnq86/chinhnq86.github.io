//import io from ('socket-io');
const io = require('socket.io')(process.env.PORT || 3000);

const arrPeerId = [];

io.on('connection', socket => {
    socket.emit('PEER_ARRAY', arrPeerId);

    socket.on('NEW_PEER_ID', peerId => {
        console.log('new id should print here');
        socket.peerId = peerId;
        console.log(socket.peerId);
        arrPeerId.push(peerId);
        io.emit('NEW_CLIENT_CONNECT', peerId);
    });

    socket.on('disconnect', () => {
        const index = arrPeerId.indexOf(socket.peerId);
        console.log('Disconnect');
        arrPeerId.splice(index, 1);
        io.emit('CLIENT_DISCONNECT', socket.peerId);
    });
});
