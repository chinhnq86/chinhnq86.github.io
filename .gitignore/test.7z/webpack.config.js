module.exports = {
    mode: 'development',
    watch: true,
    entry: './src/app.js',
    output: {
        filename: './bundle.js'
    }
}