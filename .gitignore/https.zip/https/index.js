var http = require('http');  
var express = require('express');  
var app = express();  
const ExpressPeerServer = require('peer').ExpressPeerServer;
const httpsPort = 1234;  
var https = require('https');  
var fs = require('fs');  
var options = {  
	    key: fs.readFileSync('./key.pem', 'utf8'),  
	    cert: fs.readFileSync('./server.crt', 'utf8')  
};  
const options1 = {
	    debug: true
}
//console.log("KEY: ", options.key)  
////console.log("CERT: ", options.cert)  
var secureServer = https.createServer(options, app).listen(httpsPort, () => {  
    console.log(">> CentraliZr listening at port " + httpsPort);  
    });  
const peerserver = ExpressPeerServer(secureServer, options1);
app.use('/myapp', peerserver);

    app.get('/', function(req, res) {  
        res.sendFile(__dirname + '/public/index.htm');  
        });  
